import { useEffect } from "react";
import { BrowserRouter, Routes, Route, useLocation, Link } from "react-router-dom";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/sonner";
import { AppShell } from "@/components/app-shell";
import Landing from "@/pages/Landing";
import Privacy from "@/pages/Privacy";
import Dashboard from "@/pages/Dashboard";
import Journal from "@/pages/Journal";
import Voice from "@/pages/Voice";
import Moods from "@/pages/Moods";
import Reflections from "@/pages/Reflections";
import Settings from "@/pages/Settings";
import EntryDetail from "@/pages/EntryDetail";

const queryClient = new QueryClient();

const TITLES: Record<string, [string, string]> = {
  "/": [
    "MindVault — Your private AI journal, entirely on-device",
    "MindVault is a calming AI mental health companion. Voice journaling, reflections and mood insights that never leave your device.",
  ],
  "/privacy": [
    "How Privacy Works — MindVault",
    "MindVault processes journals with on-device AI and stores them in your browser only. No cloud, no analytics.",
  ],
  "/app": ["Dashboard — MindVault", "Your mood, streak and weekly journaling activity — stored only on this device."],
  "/app/journal": ["Journal History — MindVault", "Browse every journal entry saved on this device."],
  "/app/voice": ["Voice Notes — MindVault", "Record a voice journal and transcribe it on-device."],
  "/app/moods": ["Mood Trends — MindVault", "Weekly and monthly mood charts computed locally."],
  "/app/reflections": ["AI Reflections — MindVault", "Talk things through with an on-device AI companion."],
  "/app/settings": ["Settings — MindVault", "Privacy, appearance, exports and local data deletion."],
};

function DocumentMeta() {
  const { pathname } = useLocation();
  useEffect(() => {
    const [title, description] =
      TITLES[pathname] ?? ["Journal Entry — MindVault", "A private entry, summarised locally by on-device AI."];
    document.title = title;
    let tag = document.querySelector('meta[name="description"]');
    if (!tag) {
      tag = document.createElement("meta");
      tag.setAttribute("name", "description");
      document.head.appendChild(tag);
    }
    tag.setAttribute("content", description);
  }, [pathname]);
  return null;
}

function NotFound() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-7xl font-bold">404</h1>
        <h2 className="mt-4 text-xl font-semibold">Page not found</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          The page you're looking for doesn't exist or has been moved.
        </p>
        <Link
          to="/"
          className="mt-6 inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground"
        >
          Go home
        </Link>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <BrowserRouter>
        <DocumentMeta />
        <Routes>
          <Route path="/" element={<Landing />} />
          <Route path="/privacy" element={<Privacy />} />
          <Route path="/app" element={<AppShell />}>
            <Route index element={<Dashboard />} />
            <Route path="journal" element={<Journal />} />
            <Route path="voice" element={<Voice />} />
            <Route path="moods" element={<Moods />} />
            <Route path="reflections" element={<Reflections />} />
            <Route path="settings" element={<Settings />} />
            <Route path="entry/:id" element={<EntryDetail />} />
          </Route>
          <Route path="*" element={<NotFound />} />
        </Routes>
        <Toaster position="top-center" />
      </BrowserRouter>
    </QueryClientProvider>
  );
}
